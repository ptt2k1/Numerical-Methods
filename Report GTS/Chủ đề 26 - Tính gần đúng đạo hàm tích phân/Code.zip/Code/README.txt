Hướng dẫn sử dụng code:

A. derivative_approx.py
1. Tạo file Input.txt
2. Trong file Input.txt, nhập các dữ liệu sau:
    # Dòng 1: Mốc cần tính đạo hàm
    # Các dòng tiếp theo: Mỗi dòng gồm 2 số, số thứ nhất là mốc dữ liệu, số kế tiếp là giá trị hàm tại mốc đó
3. Chạy chương trình

B. integral_approx.py
1. Chạy chương trình
2. Nhập theo hướng dẫn